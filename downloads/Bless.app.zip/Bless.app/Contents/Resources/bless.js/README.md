bless.js
=======

<http://blesscss.com>

about
-----

For more information, visit <http://blesscss.com>.

license
-------

See `LICENSE` file.

> Copyright (c) 2011 Paul Young
